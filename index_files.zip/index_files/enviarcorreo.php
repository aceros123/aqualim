<style type="text/css">
body {
	background-color: #E0E9FE;
}
body,td,th {
	font-size: 20px;
	color: #000099;
}
</style>

<? //Recepcion de datos 
$nombre=$_POST['nombre']; 

$correo=$_POST['correo']; 
$asunto=$_POST['asunto']; 
$consulta=$_POST['mensaje']; 
$para=$_POST['para']."@aqualim.com";

// Fin de recpcion de datos 

// Accion de envio 

//---------// 


$mensaje=' 

Mensaje de: 
'.$nombre.' 
Correo: 
'.$correo.' 
Asunto: 
'.$asunto.' 
"-------------------------"

Consulta: 
'.$consulta.' 
'; 
$desde='From: formulario-contacto'; 
ini_set(sendmail_from,'.$correo.'); 
mail($para,$asunto,$mensaje,$desde); 
echo' ..::Hemos recibido su mensaje. Su opini&oacute;n es muy importante para nosotros. Gracias::.. ';
?>