<style type="text/css">
body {
	background-color: #E0E9FE;
}
body,td,th {
	font-size: 20px;
	color: #000099;
}
</style>

<? //Recepcion de datos 
$ciudad=$_POST['ciudad']; 
$fecha=$_POST['fecha']; 
$cliente=$_POST['cliente']; 
$contacto=$_POST['contacto']; 
$v1=$_POST['preg1'];
$v2=$_POST['preg2'];
$v3=$_POST['preg3'];
$v4=$_POST['preg4'];
$v5=$_POST['preg5'];
$v6=$_POST['preg6'];
$v7=$_POST['preg7'];
$v8=$_POST['preg8'];
$v9=$_POST['preg9'];
$v10=$_POST['preg10'];
$total=$_POST['total'];
$asunto='Encuesta-'.$cliente;
$obs=$_POST['obs'];
$para="servicioalcliente@aqualim.com";

// Fin de recpcion de datos 
//Promedia
$total= ($v1+$v2+$v3+$v4+$v5+$v6+$v7+$v8+$v9+$v10)/10;
// Accion de envio 

//---------// 


$mensaje=' 


 Encuesta de Satisfacción del Cliente
"-----------------------------------"

Ciudad y Fecha: '.$ciudad.', '.$fecha.'
Cliente: '.$cliente.'
 Contacto: '.$contacto.'

ASPECTOS A EVALUAR  	Calificación
	_____________________________								 
	preg1       		'.$v1.'
	_____________________________
   	 preg2       		'.$v2.'
	_____________________________
  	  preg3		       	'.$v3.'
	_____________________________
	preg4	      		'.$v4.'
	_____________________________	
   	 preg5      			'.$v5.'
	_____________________________	
	preg6      			'.$v6.'
	_____________________________	
	preg7        		'.$v7.'
	_____________________________	
	preg8       		'.$v8.'
	_____________________________	
	preg9	      		'.$v9.'
	_____________________________	
	preg10      		'.$v10.'
	_____________________________        
	TOTAL   		'.$total.'
	_____________________________
OBSERVACIONES:

'.$obs.'
_____________________________ '; 

$desde=' aqualim.com '; 
ini_set(sendmail_from,'.$contacto.'); 
mail($para,$asunto,$mensaje,$desde); 
echo'..::Mensaje enviado con exito, muchas gracias::.. ';
?>

